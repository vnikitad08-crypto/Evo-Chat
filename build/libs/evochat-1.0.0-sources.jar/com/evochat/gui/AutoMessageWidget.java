package com.evochat.gui;

import com.evochat.config.EvoConfig;
import net.minecraft.class_310;
import net.minecraft.class_332;

/**
 * Small HUD widget showing auto-message status.
 * Example text: "Автосообщение: Вкл" / "Автосообщение: Выкл".
 */
public class AutoMessageWidget {

    public static void render(class_332 ctx, float tickDelta) {
        EvoConfig cfg = EvoConfig.get();
        if (!cfg.autoMessageWidgetVisible) return;

        class_310 mc = class_310.method_1551();
        if (mc.method_22683() == null) return;
        // Respect F1 (hide HUD) — hide widget together with vanilla HUD
        if (mc.field_1690.field_1842) return;

        int sw = mc.method_22683().method_4486();
        int sh = mc.method_22683().method_4502();

        int x = Math.round(cfg.autoMessageWidgetX * sw);
        int y = Math.round(cfg.autoMessageWidgetY * sh);

        String label = cfg.autoMessageEnabled
                ? "Автосообщение: Вкл"
                : "Автосообщение: Выкл";

        var tr = mc.field_1772;
        int textW = tr.method_1727(label);
        int padX = 6;
        int padY = 3;
        int w = textW + padX * 2;
        int h = 12 + padY * 2;

        int bg = cfg.autoMessageEnabled ? 0xB000D4C8 : 0xB01C2333;
        int border = cfg.autoMessageEnabled ? 0xFF00D4C8 : 0xFF8B0000;
        int textColor = cfg.autoMessageEnabled ? 0xFF55FF55 : 0xFFFF5555;

        // Shadow
        ctx.method_25294(x + 2, y + 2, x + w + 2, y + h + 2, 0x55000000);

        // Background
        ctx.method_25294(x, y, x + w, y + h, bg);

        // Border
        ctx.method_25294(x, y, x + w, y + 1, border);
        ctx.method_25294(x, y + h - 1, x + w, y + h, border);
        ctx.method_25294(x, y, x + 1, y + h, border);
        ctx.method_25294(x + w - 1, y, x + w, y + h, border);

        // Text
        ctx.method_51433(tr, label, x + padX, y + padY + 2, textColor, false);
    }
}

