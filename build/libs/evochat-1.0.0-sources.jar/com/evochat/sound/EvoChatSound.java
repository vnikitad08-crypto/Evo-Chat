package com.evochat.sound;

import com.evochat.config.EvoConfig;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3414;

/**
 * Plays a notification sound when a new ЛС message arrives.
 *
 * We re-use vanilla's "entity.experience_orb.pickup" as the
 * notification chime — it is always present and has a pleasant
 * high-pitched 'ding' quality fitting for a private-message alert.
 *
 * Players can swap to any registered SoundEvent by changing
 * SOUND_ID below without recompiling, but for the default build
 * this vanilla sound requires no extra resource-pack entry.
 */
public class EvoChatSound {

    // Vanilla sound: short, clear ping — perfect for ЛС alerts
    private static final class_2960 SOUND_ID =
            class_2960.method_60656("entity.experience_orb.pickup");

    // Debounce: don't spam the sound if many ЛС lines arrive at once
    private static long lastPlayTime = 0;
    private static final long DEBOUNCE_MS = 500;

    public static void playIfEnabled() {
        EvoConfig cfg = EvoConfig.get();
        if (!cfg.soundEnabled) return;

        long now = System.currentTimeMillis();
        if (now - lastPlayTime < DEBOUNCE_MS) return;
        lastPlayTime = now;

        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;

        class_3414 sound = net.minecraft.class_7923.field_41172.method_63535(SOUND_ID);
        if (sound == null) return;

        mc.field_1724.method_5783(sound, 0.6f, 1.4f);
    }
}
