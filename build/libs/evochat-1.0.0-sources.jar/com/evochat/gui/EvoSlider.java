package com.evochat.gui;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

/**
 * A sleek custom slider that fits EvoChat's dark-glass visual language.
 *
 * Colors: dark-navy track, cyan-teal thumb/fill, soft-white label.
 */
public class EvoSlider extends class_339 {

    // ─── Design ──────────────────────────────────────────────────────────────
    private static final int TRACK_H      = 4;
    private static final int THUMB_W      = 10;
    private static final int THUMB_H      = 18;
    private static final int COLOR_TRACK  = 0xFF1C2333;
    private static final int COLOR_FILL   = 0xFF00D4C8;
    private static final int COLOR_THUMB  = 0xFF58A6FF;
    private static final int COLOR_THUMB_HOV = 0xFF79C0FF;
    private static final int COLOR_LABEL  = 0xFFE6EDF3;
    private static final int COLOR_VALUE  = 0xFF8B949E;

    // ─── State ───────────────────────────────────────────────────────────────
    private float value;       // 0.0 – 1.0
    private final float min;
    private final float max;
    private final String label;
    private final Consumer<Float> onChanged;
    private boolean dragging = false;
    private final ValueFormatter formatter;

    public interface ValueFormatter {
        String format(float mappedValue);
    }

    public EvoSlider(int x, int y, int width, int height,
                     String label, float min, float max, float initial,
                     ValueFormatter formatter, Consumer<Float> onChanged) {
        super(x, y, width, height, class_2561.method_30163(label));
        this.label = label;
        this.min = min;
        this.max = max;
        this.value = (initial - min) / (max - min);
        this.formatter = formatter;
        this.onChanged = onChanged;
    }

    @Override
    public void method_48579(class_332 ctx, int mouseX, int mouseY, float delta) {
        int cx = method_46426();
        int cy = method_46427();
        int w  = method_25368();
        int h  = method_25364();

        int trackY = cy + h / 2 - TRACK_H / 2;
        int trackLeft  = cx + THUMB_W / 2;
        int trackRight = cx + w - THUMB_W / 2;
        int trackW     = trackRight - trackLeft;

        // Track background
        ctx.method_25294(trackLeft,  trackY, trackRight, trackY + TRACK_H, COLOR_TRACK);

        // Filled portion
        int fillX = trackLeft + (int)(value * trackW);
        ctx.method_25294(trackLeft, trackY, fillX, trackY + TRACK_H, COLOR_FILL);

        // Thumb
        int thumbX = trackLeft + (int)(value * trackW) - THUMB_W / 2;
        int thumbY = cy + h / 2 - THUMB_H / 2;
        boolean hov = mouseX >= thumbX && mouseX <= thumbX + THUMB_W
                && mouseY >= thumbY && mouseY <= thumbY + THUMB_H;
        int thumbColor = (hov || dragging) ? COLOR_THUMB_HOV : COLOR_THUMB;

        // Thumb shadow
        ctx.method_25294(thumbX + 2, thumbY + 2, thumbX + THUMB_W + 2, thumbY + THUMB_H + 2,
                0x33000000);
        // Thumb body
        ctx.method_25294(thumbX, thumbY, thumbX + THUMB_W, thumbY + THUMB_H, thumbColor);
        // Thumb inner line accent
        ctx.method_25294(thumbX + 4, thumbY + 4, thumbX + 6, thumbY + THUMB_H - 4, 0xFFFFFFFF);

        // Label on left
        var tr = net.minecraft.class_310.method_1551().field_1772;
        ctx.method_51433(tr, label, cx, cy - 12, COLOR_LABEL, false);

        // Value on right
        String valStr = formatter.format(getMappedValue());
        ctx.method_51433(tr, valStr, cx + w - tr.method_1727(valStr), cy - 12, COLOR_VALUE, false);
    }

    public float getMappedValue() {
        return min + value * (max - min);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22763 || !field_22764 || button != 0) return false;
        if (method_25405(mouseX, mouseY)) {
            dragging = true;
            updateValue(mouseX);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button,
                                double deltaX, double deltaY) {
        if (dragging) {
            updateValue(mouseX);
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        dragging = false;
        return super.method_25406(mouseX, mouseY, button);
    }

    private void updateValue(double mouseX) {
        int trackLeft  = method_46426() + THUMB_W / 2;
        int trackRight = method_46426() + method_25368() - THUMB_W / 2;
        value = (float) Math.max(0, Math.min(1,
                (mouseX - trackLeft) / (double)(trackRight - trackLeft)));
        onChanged.accept(getMappedValue());
    }

    @Override
    public void method_47399(class_6382 builder) {
        method_37021(builder);
    }
}
