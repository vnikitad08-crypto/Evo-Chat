package com.evochat.gui;

import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

/**
 * A pill-shaped toggle switch with an animated knob,
 * matching EvoChat's teal-on-dark design language.
 */
public class EvoToggle extends class_339 {

    private static final int PILL_W  = 40;
    private static final int PILL_H  = 20;
    private static final int KNOB_D  = 14;

    private static final int COLOR_ON_BG   = 0xFF00D4C8;
    private static final int COLOR_OFF_BG  = 0xFF1C2333;
    private static final int COLOR_KNOB    = 0xFFFFFFFF;
    private static final int COLOR_LABEL   = 0xFFE6EDF3;

    private boolean toggled;
    private float   knobAnim; // 0.0 = off position, 1.0 = on position
    private final String label;
    private final Consumer<Boolean> onChanged;

    public EvoToggle(int x, int y, String label, boolean initial, Consumer<Boolean> onChanged) {
        super(x, y, PILL_W, PILL_H, class_2561.method_30163(label));
        this.label     = label;
        this.toggled   = initial;
        this.knobAnim  = initial ? 1f : 0f;
        this.onChanged = onChanged;
    }

    @Override
    public void method_48579(class_332 ctx, int mouseX, int mouseY, float delta) {
        // Animate knob
        float target = toggled ? 1f : 0f;
        knobAnim += (target - knobAnim) * 0.25f;

        int cx = method_46426();
        int cy = method_46427();

        // Pill background
        int bgColor = lerpColor(COLOR_OFF_BG, COLOR_ON_BG, knobAnim);
        drawRoundRect(ctx, cx, cy, PILL_W, PILL_H, bgColor);

        // Border accent
        if (toggled) {
            drawRoundRectBorder(ctx, cx, cy, PILL_W, PILL_H, 0xFF00D4C8, 1);
        }

        // Knob
        int knobTrack = PILL_W - KNOB_D - 4;
        int knobX = cx + 2 + (int)(knobAnim * knobTrack);
        int knobY = cy + (PILL_H - KNOB_D) / 2;
        // Knob shadow
        ctx.method_25294(knobX + 1, knobY + 1, knobX + KNOB_D + 1, knobY + KNOB_D + 1, 0x44000000);
        // Knob body
        ctx.method_25294(knobX, knobY, knobX + KNOB_D, knobY + KNOB_D, COLOR_KNOB);

        // Label to the right
        var tr = class_310.method_1551().field_1772;
        ctx.method_51433(tr, label, cx + PILL_W + 8, cy + PILL_H / 2 - 4, COLOR_LABEL, false);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22763 || !field_22764 || button != 0) return false;
        if (method_25405(mouseX, mouseY)) {
            toggled = !toggled;
            onChanged.accept(toggled);
            return true;
        }
        return false;
    }

    // ─── Drawing helpers ─────────────────────────────────────────────────────
    private static void drawRoundRect(class_332 ctx, int x, int y, int w, int h, int color) {
        // Simulate rounded rect with fill + corner pixels removed
        ctx.method_25294(x + 2, y,     x + w - 2, y + h, color);
        ctx.method_25294(x,     y + 2, x + w,     y + h - 2, color);
        ctx.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, color);
    }

    private static void drawRoundRectBorder(class_332 ctx, int x, int y,
                                             int w, int h, int color, int t) {
        ctx.method_25294(x + 2, y,     x + w - 2, y + t, color);   // top
        ctx.method_25294(x + 2, y + h - t, x + w - 2, y + h, color); // bottom
        ctx.method_25294(x, y + 2, x + t, y + h - 2, color);   // left
        ctx.method_25294(x + w - t, y + 2, x + w, y + h - 2, color); // right
    }

    private static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF, aa = (a >> 24) & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF, ba = (b >> 24) & 0xFF;
        int r = ar + (int)((br - ar) * t);
        int g = ag + (int)((bg - ag) * t);
        int bl2 = ab + (int)((bb - ab) * t);
        int alpha = aa + (int)((ba - aa) * t);
        return (alpha << 24) | (r << 16) | (g << 8) | bl2;
    }

    @Override
    public void method_47399(class_6382 builder) {
        method_37021(builder);
    }
}
