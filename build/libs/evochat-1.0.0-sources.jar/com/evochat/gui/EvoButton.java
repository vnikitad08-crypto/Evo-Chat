package com.evochat.gui;

import com.evochat.chat.EvoChatWindow;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_6382;

/**
 * Slim dark-navy button with a teal accent border on hover.
 * Replaces vanilla ButtonWidget in EvoChat GUIs.
 */
public class EvoButton extends class_339 {

    private static final int COLOR_BG       = 0xFF1C2333;
    private static final int COLOR_BG_HOV   = 0xFF2D333B;
    private static final int COLOR_BORDER   = 0xFF30363D;
    private static final int COLOR_BORDER_A = 0xFF00D4C8;
    private static final int COLOR_TEXT     = 0xFFE6EDF3;
    private static final int COLOR_TEXT_HOV = 0xFFFFFFFF;

    private final Consumer<EvoButton> onPress;
    private float hoverAnim = 0f;

    public EvoButton(int x, int y, int width, int height,
                     String label, Consumer<EvoButton> onPress) {
        super(x, y, width, height, class_2561.method_30163(label));
        this.onPress = onPress;
    }

    @Override
    public void method_48579(class_332 ctx, int mouseX, int mouseY, float delta) {
        boolean hov = method_25405(mouseX, mouseY);
        hoverAnim += ((hov ? 1f : 0f) - hoverAnim) * 0.2f;

        int cx = method_46426(), cy = method_46427(), w = method_25368(), h = method_25364();

        // Shadow
        ctx.method_25294(cx + 2, cy + 2, cx + w + 2, cy + h + 2, 0x33000000);

        // Background
        int bg = lerpColor(COLOR_BG, COLOR_BG_HOV, hoverAnim);
        ctx.method_25294(cx, cy, cx + w, cy + h, bg);

        // Border
        int border = lerpColor(COLOR_BORDER, COLOR_BORDER_A, hoverAnim);
        ctx.method_25294(cx, cy,         cx + w, cy + 1,     border);  // top
        ctx.method_25294(cx, cy + h - 1, cx + w, cy + h,     border);  // bottom
        ctx.method_25294(cx, cy,         cx + 1, cy + h,     border);  // left
        ctx.method_25294(cx + w - 1, cy, cx + w, cy + h,     border);  // right

        // Accent top bar on hover
        if (hoverAnim > 0.01f) {
            ctx.method_25294(cx + 1, cy, cx + w - 1, cy + 2,
                    EvoChatWindow.withAlpha(0x00D4C8, (int)(hoverAnim * 200)));
        }

        // Label
        var tr = class_310.method_1551().field_1772;
        int txtColor = lerpColor(COLOR_TEXT, COLOR_TEXT_HOV, hoverAnim);
        int txtX = cx + w / 2 - tr.method_27525(method_25369()) / 2;
        int txtY = cy + h / 2 - 4;
        ctx.method_51439(tr, method_25369(), txtX, txtY, txtColor, false);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (!field_22763 || !field_22764 || button != 0) return false;
        if (method_25405(mouseX, mouseY)) {
            onPress.accept(this);
            return true;
        }
        return false;
    }

    private static int lerpColor(int a, int b, float t) {
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF, aa = (a >> 24) & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF, ba = (b >> 24) & 0xFF;
        int r = ar + (int)((br - ar) * t);
        int g = ag + (int)((bg - ag) * t);
        int bl2 = ab + (int)((bb - ab) * t);
        int alpha = aa + (int)((ba - aa) * t);
        return (alpha << 24) | (r << 16) | (g << 8) | bl2;
    }

    @Override
    public void method_47399(class_6382 builder) {
        method_37021(builder);
    }
}
